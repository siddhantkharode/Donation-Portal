package com.example.donationportal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class DonationServiceUnitTest {

    @Test
    public void test_createDonation() {

    }

}
