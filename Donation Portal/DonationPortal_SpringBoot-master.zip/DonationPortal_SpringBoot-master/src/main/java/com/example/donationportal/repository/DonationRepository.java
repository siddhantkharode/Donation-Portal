package com.example.donationportal.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.example.donationportal.entity.Donation;
import com.example.donationportal.entity.NGO;
import com.example.donationportal.entity.User;

@Repository
public interface DonationRepository extends CrudRepository<Donation,Integer>{

	List<Donation> findByItemType(String itemType);
	
//	@Query("SELECT d FROM Donation d WHERE d.getUserId()=?1 and d.getStatus()=?2")
	List<Donation> findByUserAndStatus(User user, String status);
	
	List<Donation> findByStatus(String status);
	
	List<Donation> findByNgoAndStatus(NGO ngo, String status);
	
	List<Donation> findByItemTypeAndStatus(String itemType, String status);
	
	public long countByUserAndStatus(User user, String status);
	
	public long countByNgoAndStatus(NGO ngo, String status);
	
	
	
}
