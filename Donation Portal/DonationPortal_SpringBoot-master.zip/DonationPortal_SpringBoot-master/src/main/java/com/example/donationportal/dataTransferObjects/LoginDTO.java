package com.example.donationportal.dataTransferObjects;



public class LoginDTO {
	
    private Integer id;

    private int userId;
    
    private String username;

    private String password;
    
    public void setId(Integer id) { this.id = id; }

    public Integer getId() { return id; }
    
    public void setUsername(String username) {
    	 this.username=username;}
    
    public String getUsername() {
    	return username;
    }
    
    public void setPassword(String password) {
    	this.password=password;
    }
    
    public String getPassword() {
    	return password;
    }
    
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

}
