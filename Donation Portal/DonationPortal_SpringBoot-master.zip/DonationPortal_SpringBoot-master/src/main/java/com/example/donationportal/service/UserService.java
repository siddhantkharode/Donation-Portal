package com.example.donationportal.service;

import com.example.donationportal.dataTransferObjects.UserDTO;
import com.example.donationportal.impl.UserServiceImpl;
import com.example.donationportal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;


public interface UserService {

    public UserDTO saveUser(UserDTO userDTO);
    public List<UserDTO> getAllUsers();
    public UserDTO updateUser(UserDTO userDTO);
    public void deleteUser(UserDTO userDTO);
    public UserDTO getUserById(Integer id);
}
