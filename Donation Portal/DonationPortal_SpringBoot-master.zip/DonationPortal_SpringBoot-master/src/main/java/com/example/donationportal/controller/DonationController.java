package com.example.donationportal.controller;


import com.example.donationportal.dataTransferObjects.DonationDTO;
import com.example.donationportal.entity.Donation;


import com.example.donationportal.service.DonationService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/donation/")
public class DonationController {

    @Autowired
    private DonationService donationService;

    @PostMapping
    @ResponseBody
    public DonationDTO addDonation(@RequestBody DonationDTO donationDTO) {
        return donationService.saveDonation(donationDTO);
    }

    @GetMapping("/count/{userId}")
    @ResponseBody
    public int getDonation(@PathVariable("userId") Integer userId) {
        //return facade.getDonationCount(userId);
        return userId;
    }

    @GetMapping("/count/{userId}/{status}")
    @ResponseBody
    public int getPendingDonations(@PathVariable("userId") Integer userId, @PathVariable("status") String status) {
        //return facade.getPendingDonations(userId);
        return userId;
    }
    
    @GetMapping("/{itemType}")
    @ResponseBody
    public List<DonationDTO> getListByItemType( @PathVariable("itemType") String itemType) {
    	return donationService.getListByItemType(itemType);
    }

    @GetMapping("/user/{userId}/{status}/")
    @ResponseBody
    public List<DonationDTO> getAllUserDonations(@PathVariable("userId") Integer userId, @PathVariable("status")String status){
    	return donationService.getAllUserDonations(userId, status);
    }
    
    @GetMapping("/all/{status}/")
    @ResponseBody
    public List<DonationDTO> getAllDonations(@PathVariable("status") String status) {
    	return donationService.getAllDonations(status);
    }
    
    @GetMapping("/{itemType}/{status}")
    @ResponseBody
    public List<DonationDTO> getListByItemTypeAndStatus( @PathVariable("itemType") String itemType, @PathVariable("status") String status) {
    	return donationService.getListByItemTypeAndStatus(itemType, status);
    }
    
    @GetMapping("/ngo/{ngoId}/{status}/")
    @ResponseBody
    public List<DonationDTO> getAllNgoDonations(@PathVariable("ngoId") Integer ngoId, @PathVariable("status")String status){
    	return donationService.getAllNgoDonations(ngoId, status);
    }
    
    @GetMapping("/count/user/{userId}/{status}/")
    @ResponseBody
    public long getCountofUserDonations(@PathVariable("userId") Integer userId, @PathVariable("status")String status){
    	return donationService.getCountofUserDonations(userId,status);
    }
    
    @GetMapping("/count/ngo/{ngoId}/{status}/")
    @ResponseBody
    public long getCountofNgoDonations(@PathVariable("ngoId") Integer ngoId, @PathVariable("status")String status){
    	return donationService.getCountofNgoDonations(ngoId,status);
    }
    
    @PutMapping("/claim/{ngoId}/")
    @ResponseBody
    public DonationDTO claimNgo(@RequestBody DonationDTO donationDTO, @PathVariable("ngoId") Integer ngoId) {
    	return donationService.claimNgo(donationDTO,ngoId);
    }
    
}
