package com.example.donationportal.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.donationportal.dataTransferObjects.LoginDTO;
import com.example.donationportal.dataTransferObjects.NgoDTO;
import com.example.donationportal.dataTransferObjects.UserDTO;
import com.example.donationportal.entity.NGO;
import com.example.donationportal.entity.User;
import com.example.donationportal.repository.NgoRepository;
import com.example.donationportal.repository.UserRepository;
import com.example.donationportal.service.LoginService;


@Service
public class LoginServiceImpl implements LoginService {
	
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private NgoRepository ngoRepository;
	
	public UserDTO checkUsername(LoginDTO loginDTO) {
		
		User user = userRepository.findByUsername(loginDTO.getUsername());
		
		UserDTO userDTO = new UserDTO();
		
		if (user != null) {
			if (user.getPassword().equals(loginDTO.getPassword())) {
				userDTO.setUsername(user.getUsername());
				userDTO.setEmail(user.getEmail());
				userDTO.setAddress(user.getAddress());
				userDTO.setCity(user.getCity());
				userDTO.setContact(user.getContact());
				userDTO.setId(user.getId());
				return userDTO;
			}
			else { return userDTO;}}
		else {  return userDTO;}
	}
	public NgoDTO checkNgoname(LoginDTO loginDTO) {
		
		NGO ngo= ngoRepository.findByNgoName(loginDTO.getUsername());
		
		NgoDTO ngoDTO = new NgoDTO();
		
		if(ngo != null) {
			if(ngo.getPassword().equals(loginDTO.getPassword())){
				ngoDTO.setNgoName(ngo.getNgoName());
				ngoDTO.setEmail(ngo.getEmail());
				ngoDTO.setAddress(ngo.getAddress());
				ngoDTO.setContact(ngo.getContact());
				ngoDTO.setCity(ngo.getCity());
				ngoDTO.setId(ngo.getId());
				return ngoDTO;
			}
			else { return ngoDTO;}}
		else { return ngoDTO;}
	}
}
