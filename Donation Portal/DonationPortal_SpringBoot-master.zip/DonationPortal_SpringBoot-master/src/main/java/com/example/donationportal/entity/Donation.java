package com.example.donationportal.entity;

import javax.persistence.*;


@Entity
@Table(name="donations_table")
public class Donation {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer id;

//    @Column(name = "user")
    @ManyToOne
    @JoinColumn(name="user_id")
    private User user;

    @Column(name = "item_type")
    private String itemType;

    @Column(name = "item_description")
    private String itemDescription;

    @Column(name = "quantity")
    private int quantity;

    @Column(name = "status")
    private String status;

//    @Column(name = "ngo")
    @ManyToOne
    @JoinColumn(name="ngo_id")
    private NGO ngo;

    public Integer getId() { return id; }

    public void setId(Integer id) { this.id = id; }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public NGO getNgo() { return ngo; }

    public void setNgo(NGO ngo) { this.ngo = ngo; }
    
}
