package com.example.donationportal.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.example.donationportal.entity.NGO;

@Repository
public interface NgoRepository extends CrudRepository<NGO, Integer> {
	
	public NGO findByNgoName(String ngoname);
}
