package com.example.donationportal.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.donationportal.dataTransferObjects.NgoDTO;
import com.example.donationportal.dataTransferObjects.UserDTO;
import com.example.donationportal.entity.NGO;
import com.example.donationportal.entity.User;
import com.example.donationportal.repository.NgoRepository;
import com.example.donationportal.service.NgoService;


@Service
public class NgoServiceImpl implements NgoService {
	
	
	@Autowired
	private NgoRepository ngoRepository;
	
	
	public NgoDTO saveNgo(NgoDTO ngoDTO) {
		
		NgoDTO responseNgoDTO = new NgoDTO();
		
		NGO ngo=new NGO();
		ngo.setId(ngoDTO.getId());
		ngo.setNgoName(ngoDTO.getNgoName());
		ngo.setPassword(ngoDTO.getPassword());
		ngo.setAddress(ngoDTO.getAddress());
		ngo.setCity(ngoDTO.getCity());
		ngo.setContact(ngoDTO.getContact());
		ngo.setEmail(ngoDTO.getEmail());
		
		NGO savedNgo = ngoRepository.save(ngo);
		
		responseNgoDTO.setId(savedNgo.getId());
		responseNgoDTO.setNgoName(savedNgo.getNgoName());
		responseNgoDTO.setAddress(savedNgo.getAddress());
		responseNgoDTO.setCity(savedNgo.getCity());
		responseNgoDTO.setContact(savedNgo.getContact());
		responseNgoDTO.setEmail(savedNgo.getEmail());
		
		return responseNgoDTO;
		
	}
	
	 public List<NgoDTO> getAllNgos(){
		 Iterable<NGO> ngosIterable = ngoRepository.findAll();
		 List<NgoDTO> ngos = new ArrayList<NgoDTO>();
		 
		 for(NGO ngo  : ngosIterable) {
			 NgoDTO ngoDTO = new NgoDTO();
			 ngoDTO.setId(ngo.getId());
			 ngoDTO.setNgoName(ngo.getNgoName());
			 ngoDTO.setPassword(ngo.getPassword());
			 ngoDTO.setAddress(ngo.getAddress());
			 ngoDTO.setCity(ngo.getCity());
			 ngoDTO.setContact(ngo.getContact());
			 ngoDTO.setEmail(ngo.getEmail());
			 
			 ngos.add(ngoDTO);
			 
		 }
		 
		 return ngos;
	 }
	 
	 public NgoDTO updateNgo(NgoDTO ngoDTO) {
		 
		 NGO ngo = ngoRepository.findById(ngoDTO.getId()).get();
		 
		 ngo.setEmail(ngoDTO.getEmail());
		 ngo.setContact(ngoDTO.getContact());
		 ngo.setAddress(ngoDTO.getAddress());
		 ngo.setCity(ngoDTO.getCity());
		 
		 NGO updatedNgo = ngoRepository.save(ngo);
		 
		 NgoDTO responseNgoDTO = new NgoDTO();
		 
		 responseNgoDTO.setId(updatedNgo.getId());
		 responseNgoDTO.setNgoName(updatedNgo.getNgoName());
		 responseNgoDTO.setContact(updatedNgo.getContact());
		 responseNgoDTO.setEmail(updatedNgo.getEmail());
		 responseNgoDTO.setAddress(updatedNgo.getAddress());
		 responseNgoDTO.setCity(updatedNgo.getCity());
		 
		 return responseNgoDTO;
		 
	 }
	 
	 public void deleteNgo(NgoDTO ngoDTO) {
	
		 NGO ngo = ngoRepository.findById(ngoDTO.getId()).get();
		 
//		 ngo.setId(ngoDTO.getId());
//		 ngo.setNgoName(ngoDTO.getNgoName());
//		 ngo.setPassword(ngoDTO.getPassword());
//		 ngo.setAddress(ngoDTO.getAddress());
//		 ngo.setCity(ngoDTO.getCity());
//		 ngo.setContact(ngoDTO.getContact());
//		 ngo.setEmail(ngoDTO.getEmail());
		 
		 ngoRepository.delete(ngo);
	 }
	 
	 public NgoDTO getNgoById(Integer id) {
	    	
    	 NGO ngo = ngoRepository.findById(id).get();
    	 
    	 NgoDTO ngoDTO= new NgoDTO();
    	 ngoDTO.setNgoName(ngo.getNgoName());
    	 ngoDTO.setId(ngo.getId());
    	 ngoDTO.setEmail(ngo.getEmail());
    	 ngoDTO.setContact(ngo.getContact());
    	 ngoDTO.setCity(ngo.getCity());
    	 ngoDTO.setAddress(ngo.getAddress());
    	
    	 return ngoDTO;
    }

}
