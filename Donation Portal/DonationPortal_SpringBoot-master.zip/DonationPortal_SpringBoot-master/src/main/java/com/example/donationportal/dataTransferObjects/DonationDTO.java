package com.example.donationportal.dataTransferObjects;

import javax.persistence.Column;

public class DonationDTO {

		private Integer id;

	    private int userId;

	    private String itemType;

	    private String itemDescription;

	    private int quantity;

	    private String status;

	    private int ngoId;

	    public Integer getId() { return id; }

	    public void setId(Integer id) { this.id = id; }

	    public int getUserId() {
	        return userId;
	    }

	    public void setUserId(int userId) {
	        this.userId = userId;
	    }

	    public String getItemType() {
	        return itemType;
	    }

	    public void setItemType(String itemType) {
	        this.itemType = itemType;
	    }

	    public String getItemDescription() {
	        return itemDescription;
	    }

	    public void setItemDescription(String itemDescription) {
	        this.itemDescription = itemDescription;
	    }

	    public int getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(int quantity) {
	        this.quantity = quantity;
	    }

	    public String getStatus() {
	        return status;
	    }

	    public void setStatus(String status) {
	        this.status = status;
	    }

	    public Integer getNgoId() { return ngoId; }

	    public void setNgoId(Integer ngoId) { this.ngoId = ngoId; }

}
