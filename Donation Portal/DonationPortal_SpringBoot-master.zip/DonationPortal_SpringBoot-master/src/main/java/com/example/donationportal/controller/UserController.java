package com.example.donationportal.controller;


import com.example.donationportal.dataTransferObjects.NgoDTO;
import com.example.donationportal.dataTransferObjects.UserDTO;
import com.example.donationportal.impl.UserServiceImpl;
import com.example.donationportal.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/user/")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping
    @ResponseBody
    public UserDTO addUser(@RequestBody UserDTO userDTO) {
        return userService.saveUser(userDTO);
    }

    @GetMapping("/all/")
    @ResponseBody
    public List<UserDTO> getAllUsers() {
        return userService.getAllUsers();
    }
    
    @GetMapping("/{id}/")
    @ResponseBody
    public UserDTO getUserById(@PathVariable("id") Integer id) {
    	return userService.getUserById(id);
    }

    @PutMapping
    @ResponseBody
    public UserDTO updateUser(@RequestBody UserDTO userDTO) {
        return userService.updateUser(userDTO);
    }

    @DeleteMapping
    @ResponseBody
    public void deleteUser(@RequestBody UserDTO userDTO) {
    	userService.deleteUser(userDTO);
    }

}
