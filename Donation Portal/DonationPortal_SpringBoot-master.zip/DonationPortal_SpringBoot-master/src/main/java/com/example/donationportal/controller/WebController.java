package com.example.donationportal.controller;


import com.example.donationportal.entity.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

class UserCredentials {
    String username;
    String password;

    public UserCredentials(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {return username;}
    public String getPassword() {return password;}
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
}

@CrossOrigin(origins="http://localhost:3000")
@Controller
@RequestMapping("/auth")
public class WebController {

    public String index() {
        return "index";
    }

    @GetMapping("/{userId}/{status}")
    @ResponseBody
    public String auth(@PathVariable("userId") Integer userId, @PathVariable("status") String status) {
        return "";
    }
}
