package com.example.donationportal.entity;

import javax.persistence.*;

@Entity
@Table(name= "ngos_table")
public class NGO {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "ngo_id")
    private Integer id;
    
    @Column(name="ngo_name")
    private String ngoName;

    @Column(name="password")
    private String password;

    @Column(name="address")
    private String address;

    @Column(name="city")
    private String city;

    @Column(name="contact")
    private String contact;

    @Column(name="email")
    private String email;

    public Integer getId() {
    	return id;
    }
    
    public void setId(Integer id) {
    	this.id=id;
    }
    public String getNgoName () {
        return ngoName;
    }

    public void setNgoName(String ngoName) {
        this.ngoName = ngoName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
