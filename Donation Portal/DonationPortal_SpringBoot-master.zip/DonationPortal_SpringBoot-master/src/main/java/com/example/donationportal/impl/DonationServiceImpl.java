package com.example.donationportal.impl;

import com.example.donationportal.dataTransferObjects.DonationDTO;
import com.example.donationportal.repository.DonationRepository;
import com.example.donationportal.repository.NgoRepository;
import com.example.donationportal.repository.UserRepository;
import com.example.donationportal.service.DonationService;
import com.example.donationportal.entity.Donation;
import com.example.donationportal.entity.NGO;
import com.example.donationportal.entity.User;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DonationServiceImpl implements DonationService{

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NgoRepository ngoRepository;

    @Autowired
    private DonationRepository donationRepository;
	
    public DonationDTO saveDonation(DonationDTO donationDTO) {
        DonationDTO responseDonationDTO = new DonationDTO();

        Donation donation = new Donation();
        donation.setUser(userRepository.findById(donationDTO.getUserId()).get());
        donation.setItemType(donationDTO.getItemType());
        donation.setItemDescription(donationDTO.getItemDescription());
        donation.setStatus("PENDING");
        donation.setQuantity(donationDTO.getQuantity());
//        donation.setNgo(ngoRepository.findById(donationDTO.getNgoId()).get());

        Donation savedDonation = donationRepository.save(donation);

        responseDonationDTO.setId(savedDonation.getId());
        responseDonationDTO.setUserId(savedDonation.getUser().getId());
        responseDonationDTO.setItemType(savedDonation.getItemType());
        responseDonationDTO.setItemDescription(savedDonation.getItemDescription());
        responseDonationDTO.setQuantity(savedDonation.getQuantity());
        responseDonationDTO.setStatus(savedDonation.getStatus());
//        responseDonationDTO.setNgoId(savedDonation.getNgo().getId());


//        BeanUtils.copyProperties(donation, donationDTO);

        return responseDonationDTO;
    }
    
    public List<DonationDTO> getAllDonations(String status){
    	
    	Iterable<Donation> listIterable=donationRepository.findByStatus(status);
    	
    	List<DonationDTO> donations = new ArrayList<DonationDTO>();
    	
    	for(Donation donation : listIterable) {
		
	    	DonationDTO donationDTO=new DonationDTO();
	   		donationDTO.setUserId(donation.getUser().getId());
	   		donationDTO.setId(donation.getId());
	   		donationDTO.setItemType(donation.getItemType());
	   		donationDTO.setItemDescription(donation.getItemDescription());
    		donationDTO.setQuantity(donation.getQuantity());
    		donationDTO.setStatus(donation.getStatus());
	    		
	    	donations.add(donationDTO);
	    	}
	    	
	    	return donations;
    }
    
    public List<DonationDTO> getListByItemType(String itemType){
    	
    	Iterable<Donation> listIterable= donationRepository.findByItemType(itemType);
    	
    	List<DonationDTO> donations = new ArrayList<DonationDTO>();
    	
    	for(Donation donation : listIterable) {
    		
    		DonationDTO donationDTO=new DonationDTO();
    		donationDTO.setUserId(donation.getUser().getId());
    		donationDTO.setId(donation.getId());
    		donationDTO.setItemType(donation.getItemType());
    		donationDTO.setItemDescription(donation.getItemDescription());
    		donationDTO.setQuantity(donation.getQuantity());
    		donationDTO.setStatus(donation.getStatus());
    		
    		donations.add(donationDTO);
    	}
    	
    	return donations;
    }
    
    public List<DonationDTO> getListByItemTypeAndStatus(String itemType, String status){
    	
    	Iterable<Donation> listIterable = donationRepository.findByItemTypeAndStatus(itemType, status);
    	List<DonationDTO> donations = new ArrayList<DonationDTO>();
    		
    	for(Donation donation : listIterable) {
    		
    		DonationDTO donationDTO=new DonationDTO();
    		donationDTO.setUserId(donation.getUser().getId());
    		donationDTO.setId(donation.getId());
    		donationDTO.setItemType(donation.getItemType());
    		donationDTO.setItemDescription(donation.getItemDescription());
    		donationDTO.setQuantity(donation.getQuantity());
    		donationDTO.setStatus(donation.getStatus());
    		
    		donations.add(donationDTO);
    	}
    	return donations;
    }
    
    public List<DonationDTO> getAllUserDonations(Integer userId, String status){
    	User user = userRepository.findById((userId)).get();
    	
    	Iterable<Donation> listIterable = donationRepository.findByUserAndStatus(user, status);
    
    	List<DonationDTO> donations = new ArrayList<DonationDTO>();
    	
    	for(Donation donation : listIterable) {
    		
    		DonationDTO donationDTO=new DonationDTO();
    		donationDTO.setUserId(donation.getUser().getId());
    		donationDTO.setId(donation.getId());
    		donationDTO.setItemType(donation.getItemType());
    		donationDTO.setItemDescription(donation.getItemDescription());
    		donationDTO.setQuantity(donation.getQuantity());
    		donationDTO.setStatus(donation.getStatus());
                if(status.equals("COMPLETED")) {donationDTO.setNgoId(donation.getNgo().getId());}
    		
    		donations.add(donationDTO);
    	}
    	return donations;
    }
    
    public List<DonationDTO> getAllNgoDonations(Integer ngoId, String status){
    	NGO ngo = ngoRepository.findById((ngoId)).get();
    	
    	Iterable<Donation> listIterable = donationRepository.findByNgoAndStatus(ngo, status);
    
    	List<DonationDTO> donations = new ArrayList<DonationDTO>();
    	
    	for(Donation donation : listIterable) {
    		
    		DonationDTO donationDTO=new DonationDTO();
    		donationDTO.setUserId(donation.getUser().getId());
    		donationDTO.setId(donation.getId());
    		donationDTO.setItemType(donation.getItemType());
    		donationDTO.setItemDescription(donation.getItemDescription());
    		donationDTO.setQuantity(donation.getQuantity());
    		donationDTO.setStatus(donation.getStatus());
    		
    		donations.add(donationDTO);
    	}
    	return donations;
    }

    public long getCountofUserDonations(Integer userId, String status) {
    	
    	User user = userRepository.findById(userId).get();
    	
    	return donationRepository.countByUserAndStatus(user,status);
    }
    
    public long getCountofNgoDonations(Integer ngoId, String status) {
    	
    	NGO ngo = ngoRepository.findById(ngoId).get();
    	
    	return donationRepository.countByNgoAndStatus(ngo,status);
    }
    
    public DonationDTO claimNgo(DonationDTO donationDTO, Integer ngoId) {
    	
    	Donation donation=donationRepository.findById(donationDTO.getId()).get();
    	
       	NGO ngo= ngoRepository.findById(ngoId).get();
    	
    	donation.setStatus("COMPLETED");
    	donation.setNgo(ngo);
    	
    	Donation savedDonation = donationRepository.save(donation);
    	
    	DonationDTO responseDonationDTO = new DonationDTO();
    	
    	responseDonationDTO.setStatus(savedDonation.getStatus());
    	responseDonationDTO.setNgoId(savedDonation.getNgo().getId());
    	responseDonationDTO.setItemType(savedDonation.getItemType());
    	responseDonationDTO.setItemDescription(savedDonation.getItemDescription());
    	responseDonationDTO.setQuantity(savedDonation.getQuantity());
    	responseDonationDTO.setId(savedDonation.getId());
    	responseDonationDTO.setUserId(savedDonation.getUser().getId());
    	return responseDonationDTO;
    	
    }
    
}
