package com.example.donationportal.service;

import com.example.donationportal.dataTransferObjects.LoginDTO;
import com.example.donationportal.dataTransferObjects.NgoDTO;
import com.example.donationportal.dataTransferObjects.UserDTO;

public interface LoginService {
	public UserDTO checkUsername(LoginDTO loginDTO);
	public NgoDTO checkNgoname(LoginDTO loginDTO);
	
}
