package com.example.donationportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.donationportal.dataTransferObjects.NgoDTO;
import com.example.donationportal.service.NgoService;
import org.springframework.web.bind.annotation.CrossOrigin;

@CrossOrigin(origins="http://localhost:3000")
@RestController
@RequestMapping("/ngo/")
public class NGOController {
	
	@Autowired
	private NgoService ngoService;

    @PostMapping
    @ResponseBody
    public NgoDTO addNGO (@RequestBody NgoDTO ngoDTO) {
        //return facade.addngo(ngo)
    	return ngoService.saveNgo(ngoDTO);
    }
    
    @GetMapping("/all/")
    @ResponseBody
    public List<NgoDTO> getAllNgos(){
    	return ngoService.getAllNgos();
    }
    
    @GetMapping("/{id}/")
    @ResponseBody
    public NgoDTO getNgoById(@PathVariable("id") Integer id) {
    	return ngoService.getNgoById(id);
    }
    
    @PutMapping
    @ResponseBody
    public NgoDTO updateNgo(@RequestBody NgoDTO ngoDTO) {
    	return ngoService.updateNgo(ngoDTO);
    }
    
    @DeleteMapping
    @ResponseBody
    public void deleteNgo(@RequestBody NgoDTO ngoDTO) {
    	ngoService.deleteNgo(ngoDTO);

    }

}
