package com.example.donationportal.impl;

import com.example.donationportal.dataTransferObjects.UserDTO;
import com.example.donationportal.entity.User;
import com.example.donationportal.repository.UserRepository;
import com.example.donationportal.service.UserService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    public UserDTO saveUser(UserDTO userDTO) {
        UserDTO responseUserDTO = new UserDTO();

        User user = new User();
        user.setId(userDTO.getId());
        user.setUsername(userDTO.getUsername());
        user.setPassword(userDTO.getPassword());
        user.setEmail(userDTO.getEmail());
        user.setContact(userDTO.getContact());
        user.setAddress(userDTO.getAddress());
        user.setCity(userDTO.getCity());

        User savedUser = userRepository.save(user);

        responseUserDTO.setId(savedUser.getId());
        responseUserDTO.setUsername(savedUser.getUsername());
        responseUserDTO.setContact(savedUser.getContact());
        responseUserDTO.setEmail(savedUser.getEmail());
        responseUserDTO.setAddress(savedUser.getAddress());
        responseUserDTO.setCity(savedUser.getCity());

//        BeanUtils.copyProperties(user, userDTO);

        return responseUserDTO;
    }

    public List<UserDTO> getAllUsers() {
        Iterable<User> usersIterable = userRepository.findAll();
        List<UserDTO> users = new ArrayList<UserDTO>();


        for (User user : usersIterable) {
            UserDTO userDTO = new UserDTO();
            userDTO.setId(user.getId());
            userDTO.setUsername(user.getUsername());
            userDTO.setContact(user.getContact());
            userDTO.setEmail(user.getEmail());
            userDTO.setAddress(user.getAddress());
            userDTO.setCity(user.getCity());

            users.add(userDTO);

        }

        return users;
    }

    public UserDTO updateUser(UserDTO userDTO) {

        User user = userRepository.findById(userDTO.getId()).get();

        user.setEmail(userDTO.getEmail());
        user.setContact(userDTO.getContact());
        user.setAddress(userDTO.getAddress());
        user.setCity(userDTO.getCity());

        User updatedUser = userRepository.save(user);

        UserDTO responseUserDTO = new UserDTO();

        responseUserDTO.setId(updatedUser.getId());
        responseUserDTO.setUsername(updatedUser.getUsername());
        responseUserDTO.setContact(updatedUser.getContact());
        responseUserDTO.setEmail(updatedUser.getEmail());
        responseUserDTO.setAddress(updatedUser.getAddress());
        responseUserDTO.setCity(updatedUser.getCity());

        return responseUserDTO;

    }

    public void deleteUser(UserDTO userDTO) {
    	
    	User user=userRepository.findById(userDTO.getId()).get();
    	
    	userRepository.delete(user);
    }
    
    public UserDTO getUserById(Integer id) {
    	
    	 User user=userRepository.findById(id).get();
    	 
    	 UserDTO userDTO= new UserDTO();
    	 userDTO.setUsername(user.getUsername());
    	 userDTO.setId(user.getId());
    	 userDTO.setEmail(user.getEmail());
    	 userDTO.setContact(user.getContact());
    	 userDTO.setCity(user.getCity());
    	 userDTO.setAddress(user.getAddress());
    	
    	 return userDTO;
    }
}
