package com.example.donationportal.service;

import java.util.List;

import com.example.donationportal.dataTransferObjects.DonationDTO;

public interface DonationService {

    public DonationDTO saveDonation(DonationDTO donationDTO);
    public List<DonationDTO> getAllDonations(String status);
    public List<DonationDTO> getListByItemType(String itemType);
    public List<DonationDTO> getListByItemTypeAndStatus(String itemType, String status);
    public List<DonationDTO> getAllUserDonations(Integer userId, String status);
    public List<DonationDTO> getAllNgoDonations(Integer ngoId, String status);
    public long getCountofUserDonations(Integer userId, String status);
    public long getCountofNgoDonations(Integer ngoId, String status);
    public DonationDTO claimNgo(DonationDTO donationDTO, Integer ngoId);
}
