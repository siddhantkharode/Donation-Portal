package com.example.donationportal.service;

import java.util.List;

import com.example.donationportal.dataTransferObjects.NgoDTO;

public interface NgoService {
	
	public NgoDTO saveNgo(NgoDTO ngoDTO);
	public List<NgoDTO> getAllNgos();
	public NgoDTO updateNgo(NgoDTO ngoDTO);
	public void deleteNgo(NgoDTO ngoDTO);
	public NgoDTO getNgoById(Integer id);
}
