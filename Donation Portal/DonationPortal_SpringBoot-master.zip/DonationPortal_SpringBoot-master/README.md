# DonationPortal_SpringBoot
This repository contains the spring boot project for the donation portal.
