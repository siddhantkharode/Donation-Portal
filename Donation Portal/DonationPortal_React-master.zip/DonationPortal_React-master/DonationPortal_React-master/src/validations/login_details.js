import Validator from "validator";
import isEmpty from "lodash/isEmpty";

export function validateInput(data) {
  let errors = {};

  if (Validator.isEmpty(data.username)) {
    errors.username = "This field is redquired";
  }
  if (Validator.isEmpty(data.password)) {
    errors.password = "This field is redquired";
  }

  return {
    errors,
    isValid: isEmpty(errors)
  };
}
