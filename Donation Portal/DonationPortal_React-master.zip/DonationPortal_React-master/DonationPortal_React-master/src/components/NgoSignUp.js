import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import { Redirect } from "react-router-dom";
import Axios from "axios";
import { Typography } from "@material-ui/core";

class NgoSignUp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nameNGO: "",
      emailNGO: "",
      contactNGO: "",
      addressNGO: "",
      cityNGO: "",
      passwordNGO: "",
      confirmPasswordNGO: "",
      signedUp: false,
      nid: null,
      errors: "",
      nextUrl: ""
    };
    this.changeNameNGO = this.changeNameNGO.bind(this);
    this.changeEmailNGO = this.changeEmailNGO.bind(this);
    this.changeContactNGO = this.changeContactNGO.bind(this);
    this.changeAddressNGO = this.changeAddressNGO.bind(this);
    this.changeCityNGO = this.changeCityNGO.bind(this);
    this.changePasswordNGO = this.changePasswordNGO.bind(this);
    this.changeConfirmPasswordNGO = this.changeConfirmPasswordNGO.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  changeNameNGO(e) {
    this.setState({ nameNGO: e.target.value });
  }
  changeEmailNGO(e) {
    this.setState({ emailNGO: e.target.value });
  }
  changeContactNGO(e) {
    this.setState({ contactNGO: e.target.value });
  }
  changeAddressNGO(e) {
    this.setState({ addressNGO: e.target.value });
  }
  changeCityNGO(e) {
    this.setState({ cityNGO: e.target.value });
  }
  changePasswordNGO(e) {
    this.setState({ passwordNGO: e.target.value });
    console.log(this.state.passwordNGO);
  }
  changeConfirmPasswordNGO(e) {
    this.setState({ confirmPasswordNGO: e.target.value });
  }

  handleSubmit(e) {
    e.preventDefault();
    if (this.state.passwordNGO === this.state.confirmPasswordNGO) {
      const user = {
        ngoName: this.state.nameNGO,
        password: this.state.passwordNGO,
        email: this.state.emailNGO,
        contact: this.state.contactNGO,
        address: this.state.addressNGO,
        city: this.state.cityNGO
      };

      Axios.post("http://localhost:8080/ngo/", user).then(res => {
        console.log(res.data);
        console.log(user);
        if (res.id !== null) {
          this.setState({
            signedUp: true,
            uid: res.data.id,
            nextUrl: "/ndash/" + res.data.id
          });
        }
      });
    } else {
      this.setState({
        errors:
          "ERROR: Password and Confirm Password are not same. Please ensure that they are same."
      });
    }
  }

  render() {
    if (this.state.signedUp === true) {
      return <Redirect to={this.state.nextUrl} />;
    }
    return (
      <div className="App">
        <form className="form-container" onSubmit={this.handleSubmit}>
          <h1 align="center">Register</h1>
          <div className="form-group">
            <p>Name of NGO</p>
            <input
              className="textBox"
              type="text"
              placeholder="Name of NGO"
              onChange={this.changeNameNGO}
              required
            />
          </div>
          <div className="form-group">
            <p>Email-id</p>
            <input
              className="textBox"
              type="email"
              placeholder="Email-id"
              onChange={this.changeEmailNGO}
              required
            />
          </div>
          <div className="form-group">
            <p>Contact Number</p>
            <input
              className="textBox"
              type="text"
              pattern="[789][0-9]{9}"
              placeholder="Contact Number"
              onChange={this.changeContactNGO}
              required
            />
          </div>
          <div className="form-group">
            <p>Address</p>
            <input
              className="textBox"
              type="text"
              placeholder="Address"
              onChange={this.changeAddressNGO}
              required
            />
          </div>
          <div className="form-group">
            <p>City of Operation</p>
            <input
              className="textBox"
              type="text"
              placeholder="City of Operation"
              onChange={this.changeCityNGO}
              required
            />
          </div>
          <Typography variant="h6" component="h6" color="error" align="center">
            {this.state.errors}
          </Typography>
          <div className="form-group">
            <p>Password</p>
            <input
              className="textBox"
              type="password"
              placeholder="Password"
              onChange={this.changePasswordNGO}
              required
            />
          </div>
          <div className="form-group">
            <p>Confirm Password</p>
            <input
              className="textBox"
              type="password"
              placeholder="Confirm Password"
              onChange={this.changeConfirmPasswordNGO}
              required
            />
          </div>
          <div className="form-group text-center">
            <input
              className="btn btn-primary mybtn"
              type="submit"
              value="Register"
            />
          </div>
        </form>
      </div>
    );
  }
}

export default NgoSignUp;
