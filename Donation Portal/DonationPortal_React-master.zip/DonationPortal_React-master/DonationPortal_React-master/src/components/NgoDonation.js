import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import Nav from "./nav";
import SideNavNgo from "./Sidenavngo";
import { Route } from "react-router-dom";
import Books_ngo from "./Books_ngo";
import Clothes_ngo from "./clothes_ngo";
import Toys_ngo from "./toys_ngo";
import Utensils_ngo from "./Utensils_ngo";
import All_ngo from "./All_ngo";

class NgoDonation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nid: this.props.match.params.id,
      type: "NGO"
    };
  }
  render() {
    return (
      <div>
        <Nav uid={this.state.nid} type={this.state.type} />
        <div className="row">
          <SideNavNgo uid={this.state.nid} />
          <Route exact path="/ndon/All_ngo/:id" component={All_ngo} />
          <Route exact path="/ndon/Books_ngo/:id" component={Books_ngo} />
          <Route exact path="/ndon/Clothes_ngo/:id" component={Clothes_ngo} />
          <Route exact path="/ndon/Toys_ngo/:id" component={Toys_ngo} />
          <Route exact path="/ndon/Utensils_ngo/:id" component={Utensils_ngo} />
        </div>
      </div>
    );
  }
}

export default NgoDonation;
