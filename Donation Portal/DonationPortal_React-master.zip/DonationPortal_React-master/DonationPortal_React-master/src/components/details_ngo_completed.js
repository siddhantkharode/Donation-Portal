import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import Nav from "./nav";
import Axios from "axios";

class Details_ngo_completed extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.match.params.id,
      listUrl:
        "http://localhost:8080/donation/ngo/" +
        this.props.match.params.id +
        "/COMPLETED/",
      donationList: []
    };
  }

  componentDidMount() {
    const listUrl = this.state.listUrl;
    Axios.get(listUrl).then(res => {
      console.log(res.data);
      this.setState({
        donationList: res.data
      });
    });
  }

  renderTable() {
    return this.state.donationList.map((donationList, index) => {
      const {
        id,
        userId,
        itemType,
        itemDescription,
        quantity,
        status,
        ngoId
      } = donationList;
      return (
        <div className="card" id="pendingTable">
          <div className="card-header">Donation {index + 1}</div>
          <div className="card-body">
            <p className="card-text">Item Type : {itemType}</p>
            <p className="card-text">Quantity : {quantity}</p>
            <p className="card-text">Item description : {itemDescription}</p>
            <p className="card-text">User ID : {userId}</p>
          </div>
        </div>
      );
    });
  }

  render() {
    return (
      <div>
        <Nav uid={this.state.uid} type="NGO" />
        <div class="form-container-pavbhaji">
          <h1 align="center">Donations Received</h1>
          {this.renderTable()}
        </div>
      </div>
    );
  }
}

export default Details_ngo_completed;
