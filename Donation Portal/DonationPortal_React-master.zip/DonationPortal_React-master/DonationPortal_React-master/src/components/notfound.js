import React from "react";
import logo from "./IMG_20190610_084419.jpg";
const Notfound = () => (
  <img
    src={logo}
    width="500"
    height="333"
    alt="The page you requested doesn't exists. Please check the url."
  />
);
export default Notfound;
