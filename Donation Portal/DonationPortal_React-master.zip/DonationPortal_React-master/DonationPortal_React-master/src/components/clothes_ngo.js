import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import Axios from "axios";
import { Button } from "@material-ui/core";

class Clothes_ngo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nid: this.props.match.params.id,
      getUrl: "http://localhost:8080/donation/clothes/PENDING/",
      availableList: []
    };
  }

  componentDidMount() {
    Axios.get(this.state.getUrl).then(res => {
      console.log(res.data);
      this.setState({
        availableList: res.data
      });
    });
  }

  renderTable() {
    return this.state.availableList.map((DonationList, index) => {
      const {
        id,
        userId,
        itemType,
        itemDescription,
        quantity,
        status,
        ngoId
      } = DonationList;
      var donationDTO = {
        id,
        userId,
        itemType,
        itemDescription,
        quantity,
        status,
        ngoId
      };
      return (
        <div class="card">
          <div class="card-header">Donation {index + 1}</div>
          <div class="card-body">
            <p class="card-text">Item Type : {itemType}</p>
            <p class="card-text">Item Description : {itemDescription}</p>
            <p class="card-text">Quantity : {quantity}</p>
          </div>
          <Button
            className={index}
            variant="contained"
            color="primary"
            enum="large"
            style={{ padding: 15, marginLeft: "40%", marginRight: "40%" }}
            onClick={HTMLElementObject => {
              console.log("lol");
              console.log(HTMLElementObject.className);
              const link =
                "http://localhost:8080/donation/claim/" + this.state.nid + "/";
              Axios.put(link, donationDTO).then(res => {
                console.log(res.data);
              });
              window.location.reload();
            }}
          >
            Accept Donation
          </Button>
        </div>
      );
    });
  }

  render() {
    return (
      <div className="form-container-donation">
        <h2 align="center">CLOTHES</h2>
        {this.renderTable()}
      </div>
    );
  }
}

export default Clothes_ngo;
