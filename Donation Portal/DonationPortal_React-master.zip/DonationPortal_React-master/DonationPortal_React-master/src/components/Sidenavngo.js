import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import { Link } from "react-router-dom";

class SideNavNgo extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nid: this.props.uid
    };
  }
  render() {
    return (
      <div className="form-container-dashboard">
        <div id="slide-out" className="side-nav fixed">
          {/* <div className="logo-wrapper waves-light">
            <a href="#">
              <img
                className="img-fluid flex-center"
                alt="Can't load it right now. Please check your connection and reload the page."
              />
            </a>
          </div> */}

          <ul className="custom-scrollbar">
            <li>
              <Link to={"/ndon/All_ngo/" + this.state.nid}>
                <a>All</a>
              </Link>
            </li>
            <li>
              <Link to={"/ndon/Clothes_ngo/" + this.state.nid}>
                <a>clothes</a>
              </Link>
            </li>
            <li>
              <Link to={"/ndon/Utensils_ngo/" + this.state.nid}>
                <a>utensils</a>
              </Link>
            </li>
            <li>
              <Link to={"/ndon/Toys_ngo/" + this.state.nid}>
                <a>toys</a>
              </Link>
            </li>
            <li>
              <Link to={"/ndon/Books_ngo/" + this.state.nid}>
                <a>books</a>
              </Link>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}

export default SideNavNgo;
