import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import Axios from "axios";

class Toys extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.match.params.id,
      quantity: 0,
      description: ""
    };
    this.onChange = this.onChange.bind(this);
    this.onChangeDesc = this.onChangeDesc.bind(this);
    this.onDonate = this.onDonate.bind(this);
  }

  onChange(e) {
    this.setState({
      quantity: e.target.value
    });
  }

  onChangeDesc(e) {
    this.setState({
      description: e.target.value
    });
  }

  onDonate(e) {
    e.preventDefault();
    const userDonation = {
      userId: this.state.uid,
      itemType: "toys",
      itemDescription: this.state.description,
      quantity: this.state.quantity
    };

    Axios.post("http://localhost:8080/donation/", userDonation).then(res => {
      console.log(res.data);
    });
    window.location.reload();
  }
  render() {
    return (
      <div className="form-container-donation">
        <h2 align="center">TOYS</h2>
        <div className="form-group">
          <span>
            <strong> Quantity :</strong>
          </span>
          <input
            className="textBox1"
            type="number"
            min="1"
            placeholder="Quantity"
            onChange={this.onChange}
          />
        </div>
        <div className="form-group">
          <p className="formfield">
            <label for="textarea">Item Description :</label>
            <textarea
              className="dabba"
              name="description"
              row="10"
              onChange={this.onChangeDesc}
            />
          </p>
        </div>
        <div className="form-group">
          <div className="container3 text-center">
            <input
              type="button"
              value="Donate"
              className="btn btn-primary mybtn donbtn"
              onClick={this.onDonate}
            />
          </div>
        </div>
      </div>
    );
  }
}

export default Toys;
