import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import SideNav from "./SideNav";
import Nav from "./nav";
import { Route } from "react-router-dom";
import Books from "./Books";
import Utensils from "./Utensils";
import Clothes from "./clothes";
import Toys from "./toys";

//const Page = ({ match }) => <p>{match.params.id}</p>;

class UserDonation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.match.params.id,
      type: "USER"
    };
  }
  render() {
    /*var determiner = null;
    if (Page == "Utensils") {
      determiner = Utensils;
    } else if (Page == "Toys") {
      determiner = Toys;
    } else if (Page == "Books") {
      determiner = Books;
    } else if (Page == "Clothes") {
      determiner = Clothes;
    }*/
    //const { url } = this.props.match;
    return (
      <div>
        <Nav uid={this.state.uid} type={this.state.type} />
        <div className="row">
          <SideNav uid={this.state.uid} />
          <Route exact path="/udon/Books/:id" component={Books} />
          <Route exact path="/udon/Clothes/:id" component={Clothes} />
          <Route exact path="/udon/Toys/:id" component={Toys} />
          <Route exact path="/udon/Utensils/:id" component={Utensils} />
        </div>
      </div>
    );
  }
}

export default UserDonation;
