import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import Nav from "./nav";
import { Link } from "react-router-dom";
import Axios from "axios";

class NgoDashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      nid: this.props.match.params.id,
      getUrl: "http://localhost:8080/ngo/" + this.props.match.params.id + "/",
      ngoName: null,
      type: "NGO",
      doneQuantity: null
    };
  }

  componentDidMount() {
    const countUrl =
      "http://localhost:8080/donation/count/ngo/" +
      this.state.nid +
      "/COMPLETED/";
    Axios.get(countUrl).then(res => {
      this.setState({
        doneQuantity: res.data
      });
    });
    const getUrl = this.state.getUrl;
    Axios.get(getUrl).then(res => {
      console.log(res.data);
      this.setState({
        ngoName: res.data.ngoName
      });
    });
  }

  render() {
    return (
      <div>
        <Nav uid={this.state.nid} type={this.state.type} />
        <div className="form-container-pavbhaji">
          <h1 align="center">Welcome {this.state.ngoName}</h1>
          <div className="dropdown" align="right">
            <div className="dropdown-menu" aria-labelledby="dropdownMenuButton">
              <a className="dropdown-item" href="#">
                Details
              </a>
              <a className="dropdown-item" href="#">
                Another action
              </a>
              <a className="dropdown-item" href="#">
                Something else here
              </a>
            </div>
          </div>

          <div className="card">
            <div className="card-header">Collections</div>
            <div className="card-body">
              <p className="card-text">
                Donations Received: {this.state.doneQuantity}
              </p>
              <Link to={"/ndetailsr/" + this.state.nid}>
                <button className="btn btn-success mybtn">View details</button>
              </Link>
            </div>
          </div>
          <div className="text-center">
            <Link to={"/ndon/All_ngo/" + this.state.nid}>
              <button className="btn btn-primary mybtn">View Donations</button>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}

export default NgoDashboard;
