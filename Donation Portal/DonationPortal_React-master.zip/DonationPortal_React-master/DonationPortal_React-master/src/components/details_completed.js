/* eslint-disable */
import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import Nav from "./nav";
import Axios from "axios";

class Details_completed extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      uid: this.props.match.params.id,
      countUrl:
        "http://localhost:8080/donation/count/user/" +
        this.props.match.params.id +
        "/COMPLETED/",
      dataTableUrl:
        "http://localhost:8080/donation/user/" +
        this.props.match.params.id +
        "/COMPLETED/",
      count: null,
      doneDonations: []
    };
  }

  componentDidMount() {
    const countUrl = this.state.countUrl;
    const dataTableUrl = this.state.dataTableUrl;
    Axios.get(countUrl).then(res => {
      console.log(res.data);
      this.setState({
        count: res.data
      });
    });
    Axios.get(dataTableUrl).then(res => {
      console.log(res.data);
      this.setState({
        doneDonations: res.data
      });
    });
  }

  renderTable() {
    return this.state.doneDonations.map((userDonations, index) => {
      const {
        id,
        userId,
        itemType,
        itemDescription,
        quantity,
        status,
        ngoId
      } = userDonations;
      return (
        <div class="card" id="pendingTable">
          <div class="card-header">Donation {index + 1}</div>
          <div class="card-body">
            <p class="card-text">Item Type : {itemType}</p>
            <p class="card-text">Quantity : {quantity}</p>
            <p class="card-text">Item description : {itemDescription}</p>
            <p class="card-text">NGO ID : {ngoId}</p>
          </div>
        </div>
      );
    });
  }

  render() {
    return (
      <div>
        <Nav uid={this.state.uid} type="USER" />
        <div className="form-container-pavbhaji">
          <h1 align="center">Donations Completed</h1>
          {this.renderTable()}
        </div>
      </div>
    );
  }
}

export default Details_completed;
