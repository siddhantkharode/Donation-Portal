import React from "react";
import "../App.css";
import "../styles/bootstrap.min.css";
import { Link, Redirect } from "react-router-dom";
import Axios from "axios";
import { Typography } from "@material-ui/core";

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "",
      password: "",
      nextUrl: "",
      uid: null,
      errors: null,
      isLoggedIn: false,
      type: "USER"
    };
    this.onChange1 = this.onChange1.bind(this);
    this.onChange2 = this.onChange2.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.handlechange = this.handlechange.bind(this);
  }

  handlechange(e) {
    if (e.target.value === "true") {
      this.setState({ type: "USER" });
    } else if (e.target.value === "false") {
      this.setState({ type: "NGO" });
    }
  }

  onChange1(e) {
    this.setState({
      username: e.target.value
    });
  }

  onChange2(e) {
    this.setState({
      password: e.target.value
    });
  }

  onSubmit(e) {
    e.preventDefault();
    console.log(this.state.type);
    const user = {
      username: this.state.username,
      password: this.state.password
    };
    if (this.state.type === "USER") {
      Axios.put("http://localhost:8080/login/username/", user).then(res => {
        console.log(res.data);
        if (res.data.id !== null) {
          this.setState({
            uid: res.data.id,
            errors: null,
            nextUrl: "/udash/" + res.data.id,
            isLoggedIn: true
          });
        } else {
          this.setState({
            errors:
              "Username or Password you entered is either incorrect or does not exist."
          });
        }
      });
    } else if (this.state.type === "NGO") {
      Axios.put("http://localhost:8080/login/ngoname/", user).then(res => {
        console.log(res.data);
        if (res.data.id !== null) {
          this.setState({
            uid: res.data.id,
            errors: null,
            nextUrl: "/ndash/" + res.data.id,
            isLoggedIn: true
          });
        } else {
          this.setState({
            errors:
              "Username or Password you entered is either incorrect or does not exist."
          });
        }
      });
    }

    // fetch("http://localhost:8080/login/username/", {
    //   method: "POST",
    //   body: JSON.stringify(user)
    // })
    //   .then(res => {
    //     console.log(res);
    //     console.log(res.body);
    //   })
    //   .catch(error => {
    //     console.log(error);
    //   });
  }

  // handleClick(event) {
  //   var apiBaseUrl = "https://192.168.10.202:8080/users/";
  //   var self = this;
  //   var payload = {
  //     email: this.state.username,
  //     password: this.state.password
  //   };
  //   Axios.post(apiBaseUrl + "login", payload)
  //     .then(function(response) {
  //       console.log(response);
  //       if (response.data.code == 200) {
  //         console.log("Login successfull");
  //         var uploadScreen = [];
  //         uploadScreen.push(
  //           <uploadScreen appContext={self.props.appContext} />
  //         );
  //         self.props.appContext.setState({
  //           Login: [],
  //           uploadScreen: uploadScreen
  //         });
  //       } else if (response.data.code == 204) {
  //         console.log("Username password do not match");
  //         alert("username password do not match");
  //       } else {
  //         console.log("Username does not exists");
  //         alert("Username does not exist");
  //       }
  //     })
  //     .catch(function(error) {
  //       console.log(error);
  //     });
  // }

  render() {
    if (this.state.isLoggedIn)
      return <Redirect to={{ pathname: this.state.nextUrl }} />;
    else
      return (
        <div className="App-login">
          <form className="form-container" onSubmit={this.onSubmit}>
            <h1 align="center">Login</h1>
            <div className="form-group">
              <p>Username :</p>
              <input
                className="textBox"
                placeholder="Username"
                onChange={this.onChange1}
                required
              />
            </div>
            <div className="form-group">
              <p>Password :</p>
              <input
                className="textBox"
                type="password"
                placeholder="Password"
                onChange={this.onChange2}
                required
                // onChange={(event, newValue) =>
                //   this.setState({ password: newValue })
                // }
              />
            </div>
            <Typography
              variant="h5"
              component="h5"
              color="error"
              align="center"
            >
              {this.state.errors}
            </Typography>

            <form align="center">
              <label class="radio-inline">
                <input
                  type="radio"
                  name="optradio"
                  value={true}
                  checked={this.state.type === "USER" ? true : false}
                  onClick={this.handlechange}
                />
                <strong
                  style={
                    this.state.type === "USER"
                      ? { color: "#007bff" }
                      : { color: "black" }
                  }
                >
                  USER
                </strong>
              </label>
              <label class="radio-inline">
                <input
                  type="radio"
                  name="optradio"
                  value={false}
                  checked={this.state.type === "NGO" ? true : false}
                  onClick={this.handlechange}
                />
                <strong
                  style={
                    this.state.type === "NGO"
                      ? { color: "#007bff" }
                      : { color: "black" }
                  }
                >
                  NGO
                </strong>
              </label>
            </form>

            <div className="form-group">
              <div className="container text-center">
                <button
                  className="btn btn-primary mybtn"
                  id="lbtn"
                  type="submit"
                  // onClick={event => this.handleClick(event)}
                >
                  Login
                </button>
              </div>
            </div>
            <div
              className="form-group"
              align="center"
              style={{ marginTop: "25px" }}
            >
              <span className="container2 text-center">
                <Link to="/signup">
                  <button className="btn btn-primary mybtn" id="sbtn">
                    User Sign Up
                  </button>
                </Link>
              </span>{" "}
              <span className="container3 text-center">
                <Link to="/ngosu">
                  <button className="btn btn-primary mybtn" id="rnbtn">
                    Register NGO
                  </button>
                </Link>
              </span>
            </div>
          </form>
        </div>
      );
  }
}
export default Login;
